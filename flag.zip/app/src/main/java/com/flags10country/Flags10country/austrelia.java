package com.flags10country.Flags10country;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class austrelia extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_austrelia);
    }
}